package com.example.infinite_runner

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
